class RelatoriosManager {
    constructor() {
        this.init();
    }

    init() {
        document.getElementById('btnExportar').onclick = () => this.exportar();
        document.getElementById('btnAgendar').onclick = () => this.agendar();
        this.carregarRelatorio();
    }

    carregarRelatorio() {
        this.carregarResumo();
        this.carregarComparativoMensal();
        this.carregarCategorias();
        this.carregarMetas();
        this.carregarInsights();
    }

    carregarResumo() {
        // Dados simulados (seriam do Firebase)
        const saldoTotal = 1250.00;
        const totalReceitas = 3000.00;
        const totalDespesas = 1750.00;
        
        document.getElementById('saldoTotal').textContent = `R$ ${saldoTotal.toFixed(2)}`;
        document.getElementById('totalReceitas').textContent = `R$ ${totalReceitas.toFixed(2)}`;
        document.getElementById('totalDespesas').textContent = `R$ ${totalDespesas.toFixed(2)}`;
        
        document.getElementById('variacaoSaldo').innerHTML = '<span class="positivo">+5.2% este mês</span>';
        document.getElementById('crescimentoReceitas').textContent = '+8.7% vs mês anterior';
        document.getElementById('reducaoDespesas').textContent = '-3.2% vs mês anterior';
    }

    carregarComparativoMensal() {
        const container = document.getElementById('graficoReceitasDespesas');
        
        container.innerHTML = `
            <div class="tabela-comparativa">
                <div class="linha-tabela cabecalho">
                    <span>Mês</span>
                    <span>Receitas</span>
                    <span>Despesas</span>
                    <span>Saldo</span>
                </div>
                <div class="linha-tabela">
                    <span>Janeiro</span>
                    <span>R$ 2.800,00</span>
                    <span>R$ 1.850,00</span>
                    <span class="positivo">R$ 950,00</span>
                </div>
                <div class="linha-tabela">
                    <span>Fevereiro</span>
                    <span>R$ 3.000,00</span>
                    <span>R$ 1.750,00</span>
                    <span class="positivo">R$ 1.250,00</span>
                </div>
                <div class="linha-tabela">
                    <span>Março</span>
                    <span>R$ 3.200,00</span>
                    <span>R$ 2.100,00</span>
                    <span class="positivo">R$ 1.100,00</span>
                </div>
            </div>
        `;
    }

    carregarCategorias() {
        const categorias = [
            { nome: 'Alimentação', valor: 700, percentual: 40 },
            { nome: 'Transporte', valor: 500, percentual: 29 },
            { nome: 'Moradia', valor: 350, percentual: 20 },
            { nome: 'Lazer', valor: 200, percentual: 11 }
        ];

        const container = document.getElementById('listaCategorias');
        container.innerHTML = categorias.map(cat => `
            <div class="categoria-card">
                <div class="categoria-info">
                    <span class="categoria-nome">${cat.nome}</span>
                    <span class="categoria-valor">R$ ${cat.valor},00</span>
                </div>
                <div class="categoria-percentual">
                    <span>${cat.percentual}% do total</span>
                </div>
            </div>
        `).join('');
    }

    carregarMetas() {
        const metas = [
            { titulo: 'Reserva de Emergência', status: 'concluida', descricao: 'Meta de R$ 10.000 atingida' },
            { titulo: 'Notebook Novo', status: 'andamento', descricao: '75% concluído - R$ 2.250/3.000' },
            { titulo: 'Curso de Especialização', status: 'pendente', descricao: 'Iniciar em breve' }
        ];

        const container = document.getElementById('listaMetas');
        container.innerHTML = metas.map(meta => `
            <div class="item-metrica status-${meta.status}">
                <div class="info-item">
                    <strong>${meta.titulo}</strong>
                    <small>${meta.descricao}</small>
                </div>
            </div>
        `).join('');
    }

    carregarInsights() {
        const insights = [
            {
                titulo: '💡 Economia Identificada',
                descricao: 'Você pode economizar R$ 150/mês reduzindo delivery',
                tipo: 'positivo'
            },
            {
                titulo: '📈 Receita em Crescimento',
                descricao: 'Suas receitas cresceram 8.7% este mês',
                tipo: 'positivo'
            },
            {
                titulo: '⚠️ Atenção a Transporte',
                descricao: 'Transporte representa 29% dos seus gastos',
                tipo: 'andamento'
            }
        ];

        const container = document.getElementById('listaInsights');
        container.innerHTML = insights.map(insight => `
            <div class="item-metrica status-${insight.tipo}">
                <div class="info-item">
                    <strong>${insight.titulo}</strong>
                    <small>${insight.descricao}</small>
                </div>
            </div>
        `).join('');
    }

    exportar() {
        alert('Relatório exportado com sucesso! 📊');
    }

    agendar() {
        alert('Relatório agendado para envio mensal! 📅');
    }
}

new RelatoriosManager();