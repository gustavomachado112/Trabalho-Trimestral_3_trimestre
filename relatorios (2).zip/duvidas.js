
document.querySelectorAll('.btn-expandir').forEach(botao => {
    botao.onclick = function() {
        const resposta = this.closest('.card-duvida').querySelector('.resposta-duvida');
        resposta.style.display = resposta.style.display === 'block' ? 'none' : 'block';
        this.textContent = resposta.style.display === 'block' ? '−' : '+';
    };
});


document.getElementById('inputPesquisa').oninput = function(e) {
    const termo = e.target.value.toLowerCase();
    
    document.querySelectorAll('.card-duvida').forEach(card => {
        const texto = card.textContent.toLowerCase();
        card.style.display = texto.includes(termo) ? 'block' : 'none';
    });
};


document.querySelectorAll('.categoria-item').forEach(categoria => {
    categoria.onclick = function() {
        document.querySelectorAll('.categoria-item').forEach(c => c.classList.remove('ativa'));
        this.classList.add('ativa');
        
        const cat = this.dataset.categoria;
        document.querySelectorAll('.card-duvida').forEach(card => {
            card.style.display = card.dataset.categoria === cat ? 'block' : 'none';
        });
    };
});