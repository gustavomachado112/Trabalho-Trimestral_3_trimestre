class OrcamentosManager {
    constructor() {
        this.orcamentos = JSON.parse(localStorage.getItem('orcamentos')) || [];
        this.categorias = this.getCategoriasFixas();
        this.init();
    }

    init() {
        document.getElementById('btnNovoOrcamento').onclick = () => this.showModal();
        document.getElementById('fecharModal').onclick = () => this.hideModal();
        document.getElementById('cancelarModal').onclick = () => this.hideModal();
        document.getElementById('formOrcamento').onsubmit = (e) => this.saveOrcamento(e);
        
        this.preencherSelects();
        this.loadOrcamentos();
    }

    getCategoriasFixas() {
        return [
            'Alimentação',
            'Transporte', 
            'Moradia',
            'Lazer',
            'Saúde',
            'Educação',
            'Vestuário',
            'Outros'
        ];
    }

    getMeses() {
        const meses = [];
        const hoje = new Date();
        
        for (let i = 0; i < 6; i++) {
            const data = new Date(hoje.getFullYear(), hoje.getMonth() + i, 1);
            const nome = data.toLocaleDateString('pt-BR', { month: 'long', year: 'numeric' });
            meses.push(nome);
        }
        
        return meses;
    }

    preencherSelects() {
        const selectCategoria = document.getElementById('selectCategoria');
        const selectMes = document.getElementById('selectMes');

        // Preencher categorias
        this.categorias.forEach(cat => {
            const option = document.createElement('option');
            option.value = cat;
            option.textContent = cat;
            selectCategoria.appendChild(option);
        });

        // Preencher meses
        this.getMeses().forEach(mes => {
            const option = document.createElement('option');
            option.value = mes;
            option.textContent = mes;
            selectMes.appendChild(option);
        });
    }

    showModal() {
        document.getElementById('modalOrcamento').style.display = 'flex';
    }

    hideModal() {
        document.getElementById('modalOrcamento').style.display = 'none';
    }

    saveOrcamento(e) {
        e.preventDefault();
        
        const orcamento = {
            id: Date.now(),
            categoria: document.getElementById('selectCategoria').value,
            valorLimite: parseFloat(document.getElementById('inputValorLimite').value),
            mes: document.getElementById('selectMes').value
        };

        if (!orcamento.categoria || orcamento.valorLimite <= 0 || !orcamento.mes) {
            alert('Preencha todos os campos');
            return;
        }

        this.orcamentos.push(orcamento);
        localStorage.setItem('orcamentos', JSON.stringify(this.orcamentos));
        this.loadOrcamentos();
        this.hideModal();
        alert('Orçamento criado!');
    }

    loadOrcamentos() {
        const container = document.getElementById('listaOrcamentos');
        
        if (this.orcamentos.length === 0) {
            container.innerHTML = '<div class="card-item">Nenhum orçamento</div>';
            return;
        }

        container.innerHTML = this.orcamentos.map(orc => `
            <div class="card-item">
                <div class="info-card">
                    <div class="icone-card">📊</div>
                    <div class="detalhes-card">
                        <h3>${orc.categoria}</h3>
                        <p>Limite: R$ ${orc.valorLimite.toFixed(2)}</p>
                        <p>Mês: ${orc.mes}</p>
                    </div>
                </div>
                <button class="btn-excluir" onclick="orcamentosManager.deleteOrcamento(${orc.id})">×</button>
            </div>
        `).join('');
    }

    deleteOrcamento(id) {
        if (confirm('Excluir orçamento?')) {
            this.orcamentos = this.orcamentos.filter(o => o.id !== id);
            localStorage.setItem('orcamentos', JSON.stringify(this.orcamentos));
            this.loadOrcamentos();
        }
    }
}

const orcamentosManager = new OrcamentosManager();