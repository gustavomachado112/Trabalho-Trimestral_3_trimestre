// Sistema SIMPLES de metas
class MetasManager {
    constructor() {
        this.metas = JSON.parse(localStorage.getItem('metas')) || [];
        this.init();
    }

    init() {
        // Eventos básicos
        document.getElementById('btnNovaMeta').onclick = () => this.showModal();
        document.getElementById('fecharModal').onclick = () => this.hideModal();
        document.getElementById('cancelarModal').onclick = () => this.hideModal();
        document.getElementById('formMeta').onsubmit = (e) => this.saveMeta(e);
        
        this.loadMetas();
    }

    showModal() {
        document.getElementById('modalMeta').style.display = 'flex';
    }

    hideModal() {
        document.getElementById('modalMeta').style.display = 'none';
    }

    saveMeta(e) {
        e.preventDefault();
        const formData = new FormData(e.target);
        
        const meta = {
            id: Date.now(),
            nome: document.getElementById('inputNome').value,
            valor: parseFloat(document.getElementById('inputValor').value),
            valorAtual: parseFloat(document.getElementById('inputValorAtual').value) || 0,
            data: document.getElementById('inputData').value,
            categoria: document.getElementById('selectCategoria').value
        };

        // Validação mínima
        if (!meta.nome || meta.valor <= 0) {
            alert('Preencha nome e valor da meta');
            return;
        }

        this.metas.push(meta);
        localStorage.setItem('metas', JSON.stringify(this.metas));
        this.loadMetas();
        this.hideModal();
        alert('Meta criada!');
    }

    loadMetas() {
        const container = document.getElementById('listaMetas');
        
        if (this.metas.length === 0) {
            container.innerHTML = '<div class="card-vazio">Nenhuma meta</div>';
            return;
        }

        container.innerHTML = this.metas.map(meta => `
            <div class="card-item">
                <div class="info-card">
                    <h3>${meta.nome}</h3>
                    <p>R$ ${meta.valorAtual} / R$ ${meta.valor}</p>
                    <div class="barra-progresso">
                        <div class="progresso" style="width: ${(meta.valorAtual/meta.valor)*100}%"></div>
                    </div>
                </div>
                <button class="btn-excluir" onclick="manager.deleteMeta(${meta.id})">×</button>
            </div>
        `).join('');
    }

    deleteMeta(id) {
        if (confirm('Excluir esta meta?')) {
            this.metas = this.metas.filter(m => m.id !== id);
            localStorage.setItem('metas', JSON.stringify(this.metas));
            this.loadMetas();
        }
    }
}

const manager = new MetasManager();