class TransacoesManager {
    constructor() {
        this.transacoes = JSON.parse(localStorage.getItem('transacoes')) || [];
        this.init();
    }

    init() {
        document.getElementById('btnNovaTransacao').onclick = () => this.showModal();
        document.getElementById('fecharModal').onclick = () => this.hideModal();
        document.getElementById('cancelarModal').onclick = () => this.hideModal();
        document.getElementById('formTransacao').onsubmit = (e) => this.saveTransacao(e);
        this.loadTransacoes();
    }

    showModal() {
        document.getElementById('modalTransacao').style.display = 'flex';
        document.getElementById('inputData').value = new Date().toISOString().split('T')[0];
    }

    hideModal() {
        document.getElementById('modalTransacao').style.display = 'none';
    }

    saveTransacao(e) {
        e.preventDefault();
        
        const transacao = {
            id: Date.now(),
            tipo: document.querySelector('input[name="tipoTransacao"]:checked').value,
            descricao: document.getElementById('inputDescricao').value,
            valor: parseFloat(document.getElementById('inputValor').value),
            data: document.getElementById('inputData').value,
            categoria: document.getElementById('selectCategoria').value
        };

        if (!transacao.descricao || transacao.valor <= 0) {
            alert('Preencha descrição e valor');
            return;
        }

        this.transacoes.push(transacao);
        localStorage.setItem('transacoes', JSON.stringify(this.transacoes));
        this.loadTransacoes();
        this.hideModal();
        alert('Transação salva!');
    }

    loadTransacoes() {
        const container = document.getElementById('listaTransacoes');
        
        if (this.transacoes.length === 0) {
            container.innerHTML = '<div class="linha-item">Nenhuma transação</div>';
            return;
        }

        container.innerHTML = this.transacoes.map(t => `
            <div class="linha-item ${t.tipo}">
                <span>${t.data}</span>
                <span>${t.descricao}</span>
                <span>${t.categoria}</span>
                <span class="${t.tipo}">R$ ${t.valor.toFixed(2)}</span>
                <button onclick="transacoesManager.deleteTransacao(${t.id})">×</button>
            </div>
        `).join('');
    }

    deleteTransacao(id) {
        if (confirm('Excluir transação?')) {
            this.transacoes = this.transacoes.filter(t => t.id !== id);
            localStorage.setItem('transacoes', JSON.stringify(this.transacoes));
            this.loadTransacoes();
        }
    }
}

const transacoesManager = new TransacoesManager();