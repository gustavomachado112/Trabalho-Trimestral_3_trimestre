class CategoriasManager {
    constructor() {
        this.categorias = JSON.parse(localStorage.getItem('categorias')) || [
            {id: 1, nome: 'Alimentação', tipo: 'despesa', cor: '#ef4444'},
            {id: 2, nome: 'Transporte', tipo: 'despesa', cor: '#f59e0b'},
            {id: 3, nome: 'Salário', tipo: 'receita', cor: '#10b981'}
        ];
        this.init();
    }

    init() {
        document.getElementById('btnNovaCategoria').onclick = () => this.showModal();
        document.getElementById('fecharModal').onclick = () => this.hideModal();
        document.getElementById('formCategoria').onsubmit = (e) => this.saveCategoria(e);
        this.loadCategorias();
    }

    showModal() {
        document.getElementById('modalCategoria').style.display = 'flex';
    }

    hideModal() {
        document.getElementById('modalCategoria').style.display = 'none';
    }

    saveCategoria(e) {
        e.preventDefault();
        
        const categoria = {
            id: Date.now(),
            nome: document.getElementById('inputNome').value,
            tipo: document.getElementById('selectTipo').value,
            cor: document.getElementById('inputCor').value
        };

        if (!categoria.nome) {
            alert('Digite o nome da categoria');
            return;
        }

        this.categorias.push(categoria);
        localStorage.setItem('categorias', JSON.stringify(this.categorias));
        this.loadCategorias();
        this.hideModal();
        alert('Categoria criada!');
    }

    loadCategorias() {
        const container = document.getElementById('listaCategorias');
        container.innerHTML = this.categorias.map(cat => `
            <div class="card-item">
                <div class="info-card">
                    <div class="icone-card" style="background: ${cat.cor}">${cat.tipo === 'receita' ? '💰' : '💸'}</div>
                    <div class="detalhes-card">
                        <h3>${cat.nome}</h3>
                        <p>${cat.tipo}</p>
                    </div>
                </div>
                <button onclick="categoriasManager.deleteCategoria(${cat.id})">×</button>
            </div>
        `).join('');
    }

    deleteCategoria(id) {
        if (confirm('Excluir categoria?')) {
            this.categorias = this.categorias.filter(c => c.id !== id);
            localStorage.setItem('categorias', JSON.stringify(this.categorias));
            this.loadCategorias();
        }
    }
}

const categoriasManager = new CategoriasManager();