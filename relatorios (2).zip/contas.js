class ContasManager {
    constructor() {
        this.contas = JSON.parse(localStorage.getItem('contas')) || [];
        this.init();
    }

    init() {
        document.getElementById('btnNovaConta').onclick = () => this.showModal();
        document.getElementById('fecharModal').onclick = () => this.hideModal();
        document.getElementById('formConta').onsubmit = (e) => this.saveConta(e);
        this.loadContas();
    }

    showModal() {
        document.getElementById('modalConta').style.display = 'flex';
    }

    hideModal() {
        document.getElementById('modalConta').style.display = 'none';
    }

    saveConta(e) {
        e.preventDefault();
        
        const conta = {
            id: Date.now(),
            nome: document.getElementById('inputNomeConta').value,
            tipo: document.getElementById('selectTipoConta').value,
            banco: document.getElementById('inputBanco').value,
            saldo: parseFloat(document.getElementById('inputSaldoInicial').value) || 0
        };

        if (!conta.nome) {
            alert('Digite o nome da conta');
            return;
        }

        this.contas.push(conta);
        localStorage.setItem('contas', JSON.stringify(this.contas));
        this.loadContas();
        this.hideModal();
        alert('Conta criada!');
    }

    loadContas() {
        const container = document.getElementById('listaContas');
        
        if (this.contas.length === 0) {
            container.innerHTML = '<div class="card-item">Nenhuma conta</div>';
            return;
        }

        container.innerHTML = this.contas.map(conta => `
            <div class="card-item">
                <div class="info-card">
                    <div class="icone-card tipo-${conta.tipo}">🏦</div>
                    <div class="detalhes-card">
                        <h3>${conta.nome}</h3>
                        <p>${conta.banco || 'Sem banco'}</p>
                        <p>Saldo: R$ ${conta.saldo.toFixed(2)}</p>
                    </div>
                </div>
                <button onclick="contasManager.deleteConta(${conta.id})">×</button>
            </div>
        `).join('');
    }

    deleteConta(id) {
        if (confirm('Excluir conta?')) {
            this.contas = this.contas.filter(c => c.id !== id);
            localStorage.setItem('contas', JSON.stringify(this.contas));
            this.loadContas();
        }
    }
}

const contasManager = new ContasManager();