class EconomiasManager {
    constructor() {
        this.economias = JSON.parse(localStorage.getItem('economias')) || [];
        this.init();
    }

    init() {
        document.getElementById('btnNovaEconomia').onclick = () => this.showModal();
        document.getElementById('fecharModal').onclick = () => this.hideModal();
        document.getElementById('formEconomia').onsubmit = (e) => this.saveEconomia(e);
        this.loadEconomias();
    }

    showModal() {
        document.getElementById('modalEconomia').style.display = 'flex';
    }

    hideModal() {
        document.getElementById('modalEconomia').style.display = 'none';
    }

    saveEconomia(e) {
        e.preventDefault();
        
        const economia = {
            id: Date.now(),
            descricao: document.getElementById('inputDescricao').value,
            tipo: document.getElementById('selectTipo').value,
            meta: parseFloat(document.getElementById('inputMeta').value),
            atual: parseFloat(document.getElementById('inputAtual').value) || 0
        };

        if (!economia.descricao || economia.meta <= 0) {
            alert('Preencha descrição e meta');
            return;
        }

        this.economias.push(economia);
        localStorage.setItem('economias', JSON.stringify(this.economias));
        this.loadEconomias();
        this.hideModal();
        alert('Economia criada!');
    }

    loadEconomias() {
        const container = document.getElementById('listaEconomias');
        
        if (this.economias.length === 0) {
            container.innerHTML = '<div class="card-item">Nenhuma economia</div>';
            return;
        }

        container.innerHTML = this.economias.map(eco => `
            <div class="card-item">
                <div class="info-card">
                    <div class="icone-card tipo-${eco.tipo}">💰</div>
                    <div class="detalhes-card">
                        <h3>${eco.descricao}</h3>
                        <p>R$ ${eco.atual.toFixed(2)} / R$ ${eco.meta.toFixed(2)}</p>
                        <div class="barra-progresso">
                            <div class="progresso" style="width: ${(eco.atual/eco.meta)*100}%"></div>
                        </div>
                    </div>
                </div>
                <button onclick="economiasManager.deleteEconomia(${eco.id})">×</button>
            </div>
        `).join('');
    }

    deleteEconomia(id) {
        if (confirm('Excluir economia?')) {
            this.economias = this.economias.filter(e => e.id !== id);
            localStorage.setItem('economias', JSON.stringify(this.economias));
            this.loadEconomias();
        }
    }
}

const economiasManager = new EconomiasManager();