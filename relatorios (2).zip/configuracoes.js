class ConfiguracoesManager {
    constructor() {
        this.config = JSON.parse(localStorage.getItem('config')) || {};
        this.init();
    }

    init() {
        document.getElementById('btnSalvarDados').onclick = () => this.salvarDados();
        document.getElementById('btnSalvarPreferencias').onclick = () => this.salvarPreferencias();
        document.getElementById('btnAlterarSenha').onclick = () => this.alterarSenha();
        this.carregarDados();
    }

    carregarDados() {
        // Preencher com dados existentes
        document.getElementById('inputNome').value = this.config.nome || '';
        document.getElementById('inputEmail').value = this.config.email || '';
    }

    salvarDados() {
        this.config.nome = document.getElementById('inputNome').value;
        this.config.email = document.getElementById('inputEmail').value;
        this.config.telefone = document.getElementById('inputTelefone').value;
        
        localStorage.setItem('config', JSON.stringify(this.config));
        alert('Dados salvos com sucesso!');
    }

    salvarPreferencias() {
        const tema = document.querySelector('input[name="tema"]:checked').value;
        this.config.tema = tema;
        localStorage.setItem('config', JSON.stringify(this.config));
        
        if (tema === 'escuro') {
            document.body.style.backgroundColor = '#1f2937';
            document.body.style.color = 'white';
        } else {
            document.body.style.backgroundColor = '#f8fafc';
            document.body.style.color = '#1f2937';
        }
        
        alert('Preferências salvas!');
    }

    alterarSenha() {
        const novaSenha = document.getElementById('inputNovaSenha').value;
        const confirmar = document.getElementById('inputConfirmarSenha').value;
        
        if (novaSenha !== confirmar) {
            alert('Senhas não coincidem!');
            return;
        }
        
        alert('Senha alterada com sucesso!');
        document.getElementById('inputNovaSenha').value = '';
        document.getElementById('inputConfirmarSenha').value = '';
    }
}

new ConfiguracoesManager();