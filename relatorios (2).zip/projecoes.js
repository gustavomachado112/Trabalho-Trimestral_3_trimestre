class ProjecoesManager {
    constructor() {
        this.init();
    }

    init() {
        document.getElementById('btnSimular').onclick = () => this.simular();
        this.simular(); // Simulação inicial
    }

    simular() {
        const periodo = parseInt(document.getElementById('selectPeriodo').value);
        const crescimento = parseFloat(document.getElementById('inputCrescimento').value) || 0;
        const investimento = parseFloat(document.getElementById('inputInvestimento').value) || 0;

        // Dados base (simulados - seriam do Firebase depois)
        const saldoAtual = 5000;
        const receitaMensal = 3000;
        const despesaMensal = 2500;

        // Cálculos simples
        const projecao = this.calcularProjecao(saldoAtual, receitaMensal, despesaMensal, crescimento, investimento, periodo);
        
        this.mostrarResultados(projecao);
        this.mostrarTabelaEvolucao(projecao);
        this.mostrarMetas(projecao.patrimonioFinal);
        
        alert('Projeção simulada com sucesso!');
    }

    calcularProjecao(saldoAtual, receitaMensal, despesaMensal, crescimento, investimento, periodo) {
        let patrimonio = saldoAtual;
        let receitaAcumulada = 0;
        const evolucao = [];

        for (let mes = 1; mes <= periodo; mes++) {
            const crescimentoFator = 1 + (crescimento / 100);
            const receitaMes = receitaMensal * Math.pow(crescimentoFator, mes);
            const saldoMes = receitaMes - despesaMensal + investimento;
            
            patrimonio += saldoMes;
            receitaAcumulada += receitaMes;
            
            evolucao.push({
                mes: mes,
                patrimonio: patrimonio,
                receitaMensal: receitaMes,
                saldoMes: saldoMes
            });
        }

        return {
            patrimonioInicial: saldoAtual,
            patrimonioFinal: patrimonio,
            receitaAnual: receitaAcumulada / (periodo / 12),
            evolucao: evolucao,
            variacao: ((patrimonio - saldoAtual) / saldoAtual) * 100
        };
    }

    mostrarResultados(projecao) {
        document.getElementById('patrimonioProjetado').textContent = 
            `R$ ${projecao.patrimonioFinal.toFixed(2)}`;
        document.getElementById('receitaAnual').textContent = 
            `R$ ${projecao.receitaAnual.toFixed(2)}`;
        
        document.getElementById('variacaoPatrimonio').textContent = 
            `${projecao.variacao >= 0 ? '+' : ''}${projecao.variacao.toFixed(1)}%`;
        document.getElementById('variacaoReceita').textContent = 
            `+${((projecao.receitaAnual - 3000) / 3000 * 100).toFixed(1)}%`;

        // Aplicar cores
        document.getElementById('variacaoPatrimonio').className = 
            `texto-variacao ${projecao.variacao >= 0 ? 'positivo' : ''}`;
    }

    mostrarTabelaEvolucao(projecao) {
        const cardGrafico = document.querySelector('.card-grafico');
        
        cardGrafico.innerHTML = `
            <h3>Evolução do Patrimônio</h3>
            <div class="tabela-evolucao">
                <div class="linha-tabela cabecalho-tabela">
                    <span>Mês</span>
                    <span>Patrimônio</span>
                    <span>Receita Mensal</span>
                    <span>Saldo do Mês</span>
                </div>
                ${projecao.evolucao.map((item, index) => `
                    <div class="linha-tabela ${index % 2 === 0 ? 'par' : 'impar'}">
                        <span>${item.mes}</span>
                        <span>R$ ${item.patrimonio.toFixed(2)}</span>
                        <span>R$ ${item.receitaMensal.toFixed(2)}</span>
                        <span class="${item.saldoMes >= 0 ? 'positivo' : 'negativo'}">
                            R$ ${item.saldoMes.toFixed(2)}
                        </span>
                    </div>
                `).join('')}
            </div>
        `;
    }

    mostrarMetas(patrimonioFinal) {
        const metas = [];
        
        if (patrimonioFinal >= 10000) {
            metas.push('✅ Reserva de Emergência (6 meses)');
        }
        if (patrimonioFinal >= 30000) {
            metas.push('✅ Entrada de Imóvel');
        }
        if (patrimonioFinal >= 50000) {
            metas.push('✅ Investimentos em Renda Fixa');
        }
        if (patrimonioFinal >= 100000) {
            metas.push('✅ Independência Financeira Parcial');
        }
        
        if (metas.length === 0) {
            metas.push('💪 Continue economizando para alcançar suas primeiras metas!');
        }

        document.getElementById('listaMetas').innerHTML = metas.map(meta => `
            <div class="item-lista">
                <div class="info-item">
                    <strong>${meta}</strong>
                </div>
            </div>
        `).join('');
    }
}

new ProjecoesManager();