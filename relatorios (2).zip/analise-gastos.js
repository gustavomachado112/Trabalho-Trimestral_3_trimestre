class AnaliseGastosManager {
    constructor() {
        this.init();
    }

    init() {
        document.getElementById('btnExportar').onclick = () => this.exportar();
        document.getElementById('btnDefinirMeta').onclick = () => this.definirMeta();
        this.carregarAnalise();
    }

    carregarAnalise() {
        // Dados simulados
        document.getElementById('totalGasto').textContent = 'R$ 1.750,00';
        document.getElementById('maiorCategoria').textContent = 'Alimentação';
        document.getElementById('economiaPotencial').textContent = 'R$ 350,00';

        // Categorias
        this.carregarCategorias();
        
        // Insights
        document.getElementById('listaInsights').innerHTML = `
            <div class="item-metrica status-alerta">
                <div class="info-item">
                    <strong>Alimentação representa 40% dos gastos</strong>
                    <small>Considere reduzir gastos com delivery</small>
                </div>
            </div>
        `;
    }

    carregarCategorias() {
        document.getElementById('listaCategorias').innerHTML = `
            <div class="linha-categoria">
                <span class="nome-categoria">Alimentação</span>
                <div class="barra-categoria"><div class="preenchimento-categoria" style="width: 70%"></div></div>
                <span class="valor-categoria">R$ 700,00</span>
            </div>
            <div class="linha-categoria">
                <span class="nome-categoria">Transporte</span>
                <div class="barra-categoria"><div class="preenchimento-categoria" style="width: 50%"></div></div>
                <span class="valor-categoria">R$ 500,00</span>
            </div>
        `;
    }

    exportar() {
        alert('Análise exportada com sucesso!');
    }

    definirMeta() {
        const meta = prompt('Meta de redução de gastos (%):', '10');
        if (meta) alert(`Meta de ${meta}% definida!`);
    }
}

new AnaliseGastosManager();