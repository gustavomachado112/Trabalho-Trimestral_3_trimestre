class PlanejamentoManager {
    constructor() {
        this.itens = JSON.parse(localStorage.getItem('planejamento')) || [];
        this.init();
    }

    init() {
        document.getElementById('btnNovoPlanejamento').onclick = () => this.novoItem();
        this.carregarItens();
    }

    novoItem() {
        const descricao = prompt('Descrição do item:');
        if (!descricao) return;

        const valor = parseFloat(prompt('Valor:'));
        if (!valor) return;

        const tipo = confirm('É receita? (OK=Sim, Cancelar=Despesa)') ? 'receita' : 'despesa';

        const item = {
            id: Date.now(),
            descricao,
            valor,
            tipo,
            status: 'previsto'
        };

        this.itens.push(item);
        localStorage.setItem('planejamento', JSON.stringify(this.itens));
        this.carregarItens();
        alert('Item adicionado!');
    }

    carregarItens() {
        const receitas = this.itens.filter(i => i.tipo === 'receita');
        const despesas = this.itens.filter(i => i.tipo === 'despesa');

        document.getElementById('listaReceitas').innerHTML = this.criarLista(receitas);
        document.getElementById('listaDespesas').innerHTML = this.criarLista(despesas);
        
        this.atualizarTotais(receitas, despesas);
    }

    criarLista(itens) {
        if (itens.length === 0) return '<div class="item-lista">Nenhum item</div>';
        
        return itens.map(item => `
            <div class="item-lista">
                <span class="texto-item">${item.descricao}</span>
                <span class="valor-item">R$ ${item.valor.toFixed(2)}</span>
                <button onclick="planejamentoManager.removerItem(${item.id})">×</button>
            </div>
        `).join('');
    }

    atualizarTotais(receitas, despesas) {
        const totalReceitas = receitas.reduce((sum, i) => sum + i.valor, 0);
        const totalDespesas = despesas.reduce((sum, i) => sum + i.valor, 0);
        
        document.getElementById('totalReceitas').textContent = `R$ ${totalReceitas.toFixed(2)}`;
        document.getElementById('totalDespesas').textContent = `R$ ${totalDespesas.toFixed(2)}`;
    }

    removerItem(id) {
        if (confirm('Remover item?')) {
            this.itens = this.itens.filter(i => i.id !== id);
            localStorage.setItem('planejamento', JSON.stringify(this.itens));
            this.carregarItens();
        }
    }
}

const planejamentoManager = new PlanejamentoManager();